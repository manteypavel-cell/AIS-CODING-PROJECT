import os
from datetime import datetime
from functools import wraps

from dotenv import load_dotenv
from flask import Flask, redirect, render_template, request, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

# Loads variables from a local .env file if one exists (for local
# development). In production, the host (Render, etc.) sets real
# environment variables directly, so this is a harmless no-op there.
load_dotenv()

app = Flask(__name__)

# --- SECRET KEY -------------------------------------------------------
# Always set a real SECRET_KEY environment variable in production.
# The fallback here only exists so the app still boots for quick local
# testing; sessions/flash messages are not safe with the fallback value.
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-key-change-me")

# --- ADMIN CREDENTIALS --------------------------------------------------
# Pulled from the environment instead of being hardcoded, so real
# credentials never live in source control. The defaults below only
# apply if the env vars are unset (e.g. first local run) — set
# ADMIN_USERNAME / ADMIN_PASSWORD for real use, especially in production.
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "aisadmin")
ADMIN_PASSWORD_HASH = generate_password_hash(
    os.environ.get("ADMIN_PASSWORD", "iamanadmin")
)

# --- DATABASE CONFIGURATION (Neon Postgres via SQLAlchemy) -------------
database_url = os.environ.get("DATABASE_URL")

if not database_url:
    raise RuntimeError(
        "DATABASE_URL environment variable is not set. "
        "Set it to your Neon Postgres connection string, e.g.\n"
        "postgresql://<user>:<password>@<host>/<db>?sslmode=require"
    )

# Neon (and some other providers/older tools) hand out connection strings
# starting with 'postgres://', but SQLAlchemy 1.4+ requires 'postgresql://'.
# Normalize it here so either form works.
if database_url.startswith("postgres://"):
    database_url = database_url.replace("postgres://", "postgresql://", 1)

app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    # Neon closes idle connections; pool_pre_ping checks a connection is
    # still alive before handing it to a request instead of erroring out.
    "pool_pre_ping": True,
}

db = SQLAlchemy(app)


# --- MODELS --------------------------------------------------------------
class Slide(db.Model):
    __tablename__ = "slides"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Text, nullable=False)
    image_url = db.Column(db.Text)
    description = db.Column(db.Text)
    date_posted = db.Column(db.Text)


class Message(db.Model):
    __tablename__ = "messages"

    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.Text)
    last_name = db.Column(db.Text)
    email = db.Column(db.Text)
    reason = db.Column(db.Text)
    date_sent = db.Column(db.Text)


with app.app_context():
    db.create_all()


# --- AUTHENTICATION DECORATOR ---
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function


# --- AUTHENTICATION ROUTES ---
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        remember_me = request.form.get("keepLoggedIn")

        if username == ADMIN_USERNAME and check_password_hash(ADMIN_PASSWORD_HASH, password):
            session["logged_in"] = True
            if remember_me:
                session.permanent = True
            return redirect(url_for("home"))

        flash("Invalid username or password.", "error")
        return redirect(url_for("login"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.pop("logged_in", None)
    return redirect(url_for("index"))


# --- PUBLIC ROUTES ---
@app.route("/")
@app.route("/index")
def index():
    return render_template("index.html")


@app.route("/news")
def news_page():
    slides = Slide.query.order_by(Slide.id.desc()).all()
    return render_template("news.html", slides=slides)


@app.route("/contact")
def contact_page():
    success = request.args.get("success")
    return render_template("contact.html", success=success)


@app.route("/submit_message", methods=["POST"])
def submit_message():
    first_name = request.form.get("firstName")
    last_name = request.form.get("lastName")
    email = request.form.get("email")
    reason = request.form.get("reason")
    date_sent = datetime.now().strftime("%b %d, %Y at %I:%M %p")

    if first_name and email and reason:
        message = Message(
            first_name=first_name,
            last_name=last_name,
            email=email,
            reason=reason,
            date_sent=date_sent,
        )
        db.session.add(message)
        db.session.commit()

    return redirect(url_for("contact_page", success="true"))


@app.route("/gallery")
def gallery():
    return render_template("gallery.html")


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/alumni")
def alumni():
    return render_template("alumni.html")


# --- PROTECTED ADMIN ROUTES ---
@app.route("/admin")
@login_required
def home():
    slides = Slide.query.order_by(Slide.id.desc()).all()
    messages = Message.query.order_by(Message.id.desc()).all()
    return render_template("admin.html", slides=slides, messages=messages)


@app.route("/admin-contact")
@login_required
def admin_contact():
    messages = Message.query.order_by(Message.id.desc()).all()
    return render_template("admin-contact.html", messages=messages)


@app.route("/register", methods=["POST"])
@login_required
def register():
    name = request.form.get("news_slide")
    image_url = request.form.get("image_url")
    description = request.form.get("description")
    date_posted = datetime.now().strftime("%B %d, %Y")

    if not image_url:
        image_url = url_for("static", filename="placeholder.png")

    if name:
        slide = Slide(
            name=name,
            image_url=image_url,
            description=description,
            date_posted=date_posted,
        )
        db.session.add(slide)
        db.session.commit()
    return redirect(url_for("home"))


@app.route("/delete_news", methods=["POST"])
@login_required
def delete_news():
    slide_id = request.form.get("slide_id")
    if slide_id:
        slide = Slide.query.get(slide_id)
        if slide:
            db.session.delete(slide)
            db.session.commit()
    return redirect(url_for("home"))


@app.route("/delete_message", methods=["POST"])
@login_required
def delete_message():
    message_id = request.form.get("message_id")
    if message_id:
        message = Message.query.get(message_id)
        if message:
            db.session.delete(message)
            db.session.commit()
    return redirect(url_for("home"))


if __name__ == "__main__":
    debug_mode = os.environ.get("FLASK_DEBUG", "true").lower() == "true"
    app.run(debug=debug_mode, host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
