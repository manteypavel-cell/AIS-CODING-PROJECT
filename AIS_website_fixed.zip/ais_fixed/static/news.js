/**
 * news.js — Akosombo International School (AIS) Sliders Engine
 * Initializes the Swiper carousels for the headline banner and any
 * multi-image news cards. The actual slide content comes from the
 * `slides` data the Flask /news route renders server-side (see
 * templates/news.html) — this file only wires up the carousel behavior.
 *
 * Note: an earlier version of this file also tried to fetch news/headline
 * data from a REST API (/api/news, /api/headlines) that this Flask app
 * never implements — that dead code (which always failed and silently
 * did nothing) has been removed.
 */

document.addEventListener('DOMContentLoaded', () => {
    initSliders();
});

// Initialize Swiper sliders
function initSliders() {
    // 1. Initialize Headline Slider
    if (document.querySelector('.headline-swiper')) {
        new Swiper('.headline-swiper', {
            direction: 'horizontal',
            slidesPerView: 1,
            loop: true,
            autoplay: {
                delay: 3500,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.headline-swiper .swiper-pagination',
                clickable: true,
            },
        });
    }

    // 2. Initialize Card Sliders (news items with multiple images)
    document.querySelectorAll('.card-swiper').forEach(sliderEl => {
        new Swiper(sliderEl, {
            direction: 'horizontal',
            slidesPerView: 1,
            loop: true,
            autoplay: {
                delay: 2800,
                disableOnInteraction: false,
            },
            pagination: {
                el: sliderEl.querySelector('.swiper-pagination'),
                clickable: true,
            },
        });
    });
}
